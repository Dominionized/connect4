package ca.csf.connect4.server;

/**
 * Created by Anthony on 15/12/2015.
 */
public class ServerConfig {

}

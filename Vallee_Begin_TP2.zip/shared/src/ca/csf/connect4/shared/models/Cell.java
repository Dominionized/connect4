package ca.csf.connect4.shared.models;

public enum Cell {
    RED, BLACK, EMPTY
}

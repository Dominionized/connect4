package ca.csf.connect4.shared;

/**
 * Created by Anthony on 15/12/2015.
 */
public class NetworkConfig {
    public static final int DEFAULT_LISTEN_PORT = 7331;
}
